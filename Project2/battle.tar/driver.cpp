/******************************************************
** Program: driver.cpp
** Author: Padraic Bergin
** Date: 10/31/2021
** Description: creates a arena object that then runs the game
** Input: none
** Output: none
******************************************************/
#include <iostream>
#include "pokemon.h"
#include "bulbasaur.h"
#include "charmander.h"
#include "squirtle.h"
#include "trainer.h"
#include "charizard.h"
#include "arena.h"

#include <fstream>
using namespace std;

int main(){
    Arena a1;
    return 0;
}
